<?php
 // Template Name: lyd-photos
       create_section_top('Photos', false);
       lyd_photo_gallery();
       // echo $about_post;
 ?> 
<?php create_section_bottom(); ?>