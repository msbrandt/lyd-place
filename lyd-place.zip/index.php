<?php 
/**
*
* @subpackage LYDIAS PLACE
* @since Today
*/

create_hero_reg('default');
?>

</section>
<?php
  get_footer();
?>