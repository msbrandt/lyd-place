jQuery(function($){
	console.log('slience is golden');
});