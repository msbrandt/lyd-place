<?php ?>

</main>

<footer id="footer" >
	<?php real_footer_nav(); ?>
</footer>


</div>

	<?php  wp_footer(); ?>

</body>
</html>
<?php ?>